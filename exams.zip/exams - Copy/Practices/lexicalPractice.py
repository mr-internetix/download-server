import re

open(file="InputProg.c")